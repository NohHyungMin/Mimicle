package app.com.mimicle.model

data class NetworkResponse (
    val result: String = ""
)