package app.com.mimicle.webinterface

import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast

class WebAppInterface(private val mContext: Context) {
    /** Show a toast from the web page  */
    @JavascriptInterface
    fun showToast(toast: String) {
        Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show()
//        web_content!!.post {
//            if (web_content!!.canGoBack() && web_content!!.url != "https://booking.pregolfshow.com/golfclubs") {
//                web_content!!.goBack()
//            } else {
//            }
//        }
    }
}