
    function test(){
        try{
            alert('a');
            window.Bridge.showToast('test');
        }catch(err){
            console.log(">> [exam_script.plus_num()] " + err);
        }
    }

